const form = document.querySelector("#chat-form");
const input = document.querySelector("#message-input");
const messages = document.querySelector("#messages");
const voiceButton = document.querySelector("#voice-button");

form.addEventListener("submit", (event) => {
  event.preventDefault();
  const value = input.value.trim();
  if (!value) return;

  const message = document.createElement("div");
  message.className = "user-line";
  message.textContent = value;
  messages.appendChild(message);
  input.value = "";

  const reply = document.createElement("div");
  reply.className = "mind-message";
  reply.innerHTML = '<span class="mind-avatar">M</span><div><strong>MIND · MODE DÉMO</strong><p>Ton message est bien affiché. La connexion à une intelligence artificielle sera ajoutée dans une prochaine étape.</p></div>';
  messages.appendChild(reply);
});

voiceButton.addEventListener("click", () => {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognition) {
    alert("La dictée vocale n'est pas prise en charge par ce navigateur. Tu pourras utiliser le mode vocal après l'intégration dédiée.");
    return;
  }
  const recognition = new SpeechRecognition();
  recognition.lang = "fr-FR";
  recognition.onresult = (event) => {
    input.value = event.results[0][0].transcript;
    input.focus();
  };
  recognition.start();
});
